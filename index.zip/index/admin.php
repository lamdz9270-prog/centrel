<?php
session_start();
require_once '../config/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $ip = $_SERVER['REMOTE_ADDR'];
    
    // 1. Tìm admin
    $admin = findAdmin($username);
    
    if (!$admin) {
        logLoginAttempt($username, $ip, false, 'Username không tồn tại');
        $error = '❌ Sai tên đăng nhập hoặc mật khẩu';
    }
    // 2. Kiểm tra password
    elseif (!password_verify($password, $admin['password'])) {
        logLoginAttempt($username, $ip, false, 'Sai mật khẩu');
        $error = '❌ Sai tên đăng nhập hoặc mật khẩu';
    }
    // 3. Kiểm tra tài khoản active
    elseif (!$admin['is_active']) {
        logLoginAttempt($username, $ip, false, 'Tài khoản bị khóa');
        $error = '❌ Tài khoản đã bị khóa';
    }
    // 4. 🔥 KIỂM TRA IP (QUAN TRỌNG)
    elseif (!isIPValid($username, $ip)) {
        logLoginAttempt($username, $ip, false, 'IP không khớp với IP đăng ký');
        $error = '❌ IP của bạn không được phép đăng nhập vào tài khoản này.
                  <br>IP đăng ký: ' . ($admin['registered_ip'] ?? 'Chưa có') . '
                  <br>IP hiện tại: ' . $ip . '
                  <br>🔒 Liên hệ Master Admin để cập nhật IP.';
    }
    // ✅ THÀNH CÔNG
    else {
        // Cập nhật IP hiện tại
        updateAdminIP($username, $ip);
        logLoginAttempt($username, $ip, true, 'Đăng nhập thành công');
        
        // Lưu session
        $_SESSION['user_id'] = $admin['id'];
        $_SESSION['username'] = $admin['username'];
        $_SESSION['role'] = $admin['role'];
        $_SESSION['fullname'] = $admin['fullname'];
        $_SESSION['registered_ip'] = $admin['registered_ip'];
        $_SESSION['current_ip'] = $ip;
        $_SESSION['key_quota'] = $admin['key_quota'] ?? 0;
        $_SESSION['keys_used'] = $admin['keys_used'] ?? 0;
        
        header('Location: dashboard.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .container { max-width: 400px; }
        .ip-info {
            font-size: 12px;
            color: #868e96;
            background: #f8f9fa;
            padding: 10px 14px;
            border-radius: 8px;
            margin: 12px 0;
            word-break: break-all;
        }
        .ip-info strong { color: #212529; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔐 Admin Login</h1>
        <p class="sub">Đăng nhập để quản lý hệ thống</p>
        
        <?php if ($error): ?>
            <div class="msg error" style="display:block;white-space:pre-line;"><?= $error ?></div>
        <?php endif; ?>
        
        <div class="ip-info">
            📡 IP của bạn: <strong><?= $_SERVER['REMOTE_ADDR'] ?></strong>
        </div>
        
        <form method="POST">
            <div class="form-group">
                <label>Tên đăng nhập</label>
                <input type="text" name="username" placeholder="Nhập username..." required>
            </div>
            <div class="form-group">
                <label>Mật khẩu</label>
                <input type="password" name="password" placeholder="Nhập mật khẩu..." required>
            </div>
            <button type="submit" class="btn">Đăng nhập →</button>
        </form>
        
        <div class="brand">DUCLAM.NET · Configuration Centre</div>
    </div>
</body>
</html>