<?php
session_start();
if ($_SESSION['role'] !== 'master') {
    die('🚫 Chỉ Master Admin mới có quyền!');
}

require_once '../config/db.php';

$result = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $fullname = trim($_POST['fullname'] ?? '');
    $key_quota = (int)($_POST['key_quota'] ?? 10);
    
    // Kiểm tra username
    if (strlen($username) < 3) {
        $result = ['error' => 'Username phải có ít nhất 3 ký tự'];
    } elseif (strlen($password) < 6) {
        $result = ['error' => 'Mật khẩu phải có ít nhất 6 ký tự'];
    } else {
        $result = createAdmin($username, $password, $fullname, 'admin', $key_quota);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tạo Admin Con</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <div class="container">
        <h1>➕ Tạo Admin Con</h1>
        <p class="sub">Tạo tài khoản admin mới (chỉ Master)</p>
        
        <?php if ($result): ?>
            <?php if (isset($result['error'])): ?>
                <div class="msg error" style="display:block;">❌ <?= $result['error'] ?></div>
            <?php else: ?>
                <div class="msg success" style="display:block;">
                    ✅ Tạo admin thành công!<br>
                    Username: <strong><?= $result['admin']['username'] ?></strong><br>
                    Mật khẩu: <strong><?= $_POST['password'] ?></strong><br>
                    <span style="color:#868e96;font-size:13px;">Lưu lại mật khẩu này để cấp cho admin.</span>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label>👤 Username</label>
                <input type="text" name="username" placeholder="VD: admin1" required>
            </div>
            <div class="form-group">
                <label>🔑 Mật khẩu</label>
                <input type="text" name="password" placeholder="Mật khẩu tối thiểu 6 ký tự" required>
            </div>
            <div class="form-group">
                <label>📛 Tên hiển thị</label>
                <input type="text" name="fullname" placeholder="VD: Admin 1 - Quang Hào" required>
            </div>
            <div class="form-group">
                <label>📦 Số lượng key được tạo</label>
                <input type="number" name="key_quota" value="10" min="1" max="9999">
            </div>
            <button type="submit" class="btn">Tạo admin →</button>
        </form>
        
        <div style="margin-top:16px;text-align:center;">
            <a href="manage_admins.php" style="color:#868e96;font-size:14px;text-decoration:none;">← Về quản lý admin</a>
        </div>
        <div class="brand">DUCLAM.NET · Configuration Centre</div>
    </div>
</body>
</html>