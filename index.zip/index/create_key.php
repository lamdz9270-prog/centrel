<?php
session_start();
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'master' && $_SESSION['role'] !== 'admin')) {
    die('🚫 Bạn không có quyền truy cập!');
}

require_once '../config/db.php';
$data = loadDB();

// Kiểm tra quota
$current_user = null;
foreach ($data['admins'] as $a) {
    if ($a['username'] === $_SESSION['username']) {
        $current_user = $a;
        break;
    }
}

if ($current_user && ($current_user['keys_used'] ?? 0) >= ($current_user['key_quota'] ?? 0)) {
    die('❌ Bạn đã hết quota tạo key. Liên hệ Master để gia hạn.');
}

// Danh sách chức năng
$feature_options = [
    'dns' => '🌐 DNS tùy chỉnh',
    'proxy' => '🔗 Proxy',
    'vpn' => '🔒 VPN',
    'certificate' => '📜 Chứng chỉ',
    'ad_block' => '🚫 Chặn quảng cáo',
    'game_boost' => '⚡ Tăng tốc game',
    'wifi_optimize' => '📶 Tối ưu WiFi'
];

$result = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $package = $_POST['package'] ?? 'vip';
    $expires_days = (int)($_POST['expires_days'] ?? 365);
    $max_udid = (int)($_POST['max_udid'] ?? 1);
    $admin_zalo = trim($_POST['admin_zalo'] ?? '');
    $admin_name = trim($_POST['admin_name'] ?? '');
    
    // Lấy chức năng được chọn
    $features = [];
    foreach ($feature_options as $key => $name) {
        $features[$key] = isset($_POST['feature_' . $key]);
    }
    
    // DNS tùy chỉnh
    if ($features['dns'] && !empty($_POST['custom_dns'])) {
        $dns_list = array_filter(array_map('trim', explode("\n", $_POST['custom_dns'])));
        if (!empty($dns_list)) {
            $features['custom_dns'] = $dns_list;
        }
    }
    
    // Tạo key code
    $prefix = strtoupper(substr($package, 0, 3));
    $hash = strtoupper(substr(md5(uniqid() . rand(1000, 9999)), 0, 8));
    $key_code = $prefix . '-' . date('Ymd') . '-' . $hash . '-' . rand(100, 999);
    
    // Tạo key mới
    $new_key = [
        'id' => 'K' . rand(1000, 9999),
        'key_code' => $key_code,
        'package' => $package,
        'created_by' => $_SESSION['username'],
        'created_at' => date('Y-m-d H:i:s'),
        'expires_at' => date('Y-m-d H:i:s', strtotime("+$expires_days days")),
        'max_udid' => $max_udid,
        'used_udid' => 0,
        'features' => $features,
        'admin_info' => [
            'name' => $admin_name ?: $_SESSION['fullname'] ?? 'Đức Lâm X Quang Hào',
            'zalo' => $admin_zalo ?: '0879072010'
        ],
        'status' => 'active',
        'usage_logs' => []
    ];
    
    // Lưu key
    $data['keys'][] = $new_key;
    
    // Tăng keys_used cho admin
    foreach ($data['admins'] as &$a) {
        if ($a['username'] === $_SESSION['username']) {
            $a['keys_used'] = ($a['keys_used'] ?? 0) + 1;
            break;
        }
    }
    
    saveDB($data);
    $result = ['success' => true, 'key' => $key_code];
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tạo Key</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .quota-info {
            background: #f8f9fa;
            padding: 12px 16px;
            border-radius: 10px;
            margin-bottom: 16px;
            font-size: 14px;
            display: flex;
            justify-content: space-between;
        }
        .quota-info .used { color: #212529; font-weight: 600; }
        .quota-info .total { color: #868e96; }
        .quota-info .warning { color: #e03131; }
        .check-group {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 6px;
            margin: 8px 0 12px;
        }
        .check-group label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            font-weight: 400;
            color: #495057;
            background: #f8f9fa;
            padding: 6px 10px;
            border-radius: 6px;
            cursor: pointer;
        }
        .check-group label:hover { background: #e9ecef; }
        .check-group input[type="checkbox"] { width: 16px; height: 16px; accent-color: #212529; }
    </style>
</head>
<body>
    <div class="container" style="max-width:560px;">
        <h1>🔑 Tạo Key</h1>
        <p class="sub">Tạo key mới để cấp cho khách hàng</p>
        
        <!-- Quota -->
        <?php if ($current_user): ?>
        <div class="quota-info">
            <span>📦 Quota key</span>
            <span>
                <span class="used"><?= $current_user['keys_used'] ?? 0 ?></span>
                <span class="total">/ <?= $current_user['key_quota'] ?? 0 ?></span>
                <?php if (($current_user['keys_used'] ?? 0) >= ($current_user['key_quota'] ?? 0)): ?>
                    <span class="warning"> ⚠️ Đã hết!</span>
                <?php endif; ?>
            </span>
        </div>
        <?php endif; ?>
        
        <?php if ($result && isset($result['success'])): ?>
            <div class="msg success" style="display:block;">
                ✅ Tạo key thành công!<br>
                <strong>Key: <?= $result['key'] ?></strong><br>
                <span style="font-size:13px;color:#868e96;">Lưu key này để cấp cho khách.</span>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <!-- Gói -->
            <div class="form-group">
                <label>📦 Gói</label>
                <select name="package">
                    <option value="vip">VIP</option>
                    <option value="gold">GOLD</option>
                    <option value="free">FREE</option>
                    <option value="premium">PREMIUM</option>
                </select>
            </div>
            
            <!-- Thời hạn -->
            <div class="form-group">
                <label>⏳ Thời hạn (ngày)</label>
                <input type="number" name="expires_days" value="365" min="1" max="9999">
            </div>
            
            <!-- Số lượng UDID -->
            <div class="form-group">
                <label>📱 Số lượng thiết bị tối đa</label>
                <input type="number" name="max_udid" value="1" min="1" max="999">
            </div>
            
            <!-- Chức năng -->
            <div style="font-size:13px;font-weight:500;color:#495057;margin:12px 0 4px;">📦 Chức năng</div>
            <div class="check-group">
                <?php foreach ($feature_options as $key => $name): ?>
                <label>
                    <input type="checkbox" name="feature_<?= $key ?>" value="1" checked>
                    <?= $name ?>
                </label>
                <?php endforeach; ?>
            </div>
            
            <!-- DNS tùy chỉnh -->
            <div class="form-group">
                <label>🌐 DNS tùy chỉnh (1 dòng 1 IP)</label>
                <textarea name="custom_dns" placeholder="1.1.1.1&#10;8.8.8.8&#10;9.9.9.9" rows="3"></textarea>
            </div>
            
            <!-- Thông tin admin -->
            <div style="border-top:1px solid #e9ecef;padding-top:16px;margin-top:8px;">
                <div style="font-size:13px;font-weight:500;color:#495057;margin-bottom:8px;">👤 Thông tin liên hệ (hiển thị trong config)</div>
                <div class="form-group">
                    <label>Tên admin</label>
                    <input type="text" name="admin_name" value="<?= $_SESSION['fullname'] ?? 'Đức Lâm X Quang Hào' ?>">
                </div>
                <div class="form-group">
                    <label>Zalo</label>
                    <input type="text" name="admin_zalo" value="0879072010">
                </div>
            </div>
            
            <button type="submit" class="btn" <?= (($current_user['keys_used'] ?? 0) >= ($current_user['key_quota'] ?? 0)) ? 'disabled' : '' ?>>
                Tạo key →
            </button>
        </form>
        
        <div style="margin-top:16px;text-align:center;">
            <a href="dashboard.php" style="color:#868e96;font-size:14px;text-decoration:none;">← Về dashboard</a>
        </div>
        <div class="brand">DUCLAM.NET · Configuration Centre</div>
    </div>
</body>
</html>