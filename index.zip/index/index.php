<?php
// Hiển thị form nhập key
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuration Centre 🧩</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .feature-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 12px;
            background: #f8f9fa;
            border-radius: 8px;
            margin-bottom: 4px;
            font-size: 14px;
        }
        .feature-item .icon { font-size: 16px; }
        .feature-item .label { color: #212529; }
        .badge {
            font-size: 11px;
            padding: 2px 10px;
            border-radius: 20px;
            background: #e9ecef;
            color: #495057;
        }
        .admin-contact {
            margin-top: 16px;
            padding: 12px;
            background: #f1f3f5;
            border-radius: 10px;
            font-size: 13px;
            text-align: center;
            color: #495057;
        }
        .admin-contact a {
            color: #212529;
            text-decoration: none;
            font-weight: 600;
        }
        .hidden { display: none; }
    </style>
</head>
<body>
    <div class="container" id="app">
        <!-- STEP 1: NHẬP KEY -->
        <div id="step-key">
            <h1>🔑 Configuration Centre</h1>
            <p class="sub">Nhập key để tải cấu hình</p>
            
            <div class="form-group">
                <label>License Key</label>
                <input type="text" id="keyInput" placeholder="VD: VIP2026-ABCD-EFGH-1234" 
                       onkeydown="if(event.key==='Enter') validateKey()">
            </div>
            
            <button class="btn" onclick="validateKey()" id="btnCheck">Kiểm tra key →</button>
            <div id="msg" class="msg"></div>
        </div>
        
        <!-- STEP 2: HIỂN THỊ THÔNG TIN KEY + NHẬP UDID -->
        <div id="step-udid" class="hidden">
            <h1>📱 Configuration Centre 🧩</h1>
            <p class="sub" id="configSub">DUCLAM.NET</p>
            
            <!-- Thông tin key -->
            <div style="background:#f8f9fa;border-radius:10px;padding:16px;margin:16px 0;">
                <div style="display:flex;justify-content:space-between;font-size:13px;">
                    <span style="color:#868e96;">🔑 Key:</span>
                    <span style="font-weight:600;" id="displayKey">---</span>
                </div>
                <div style="display:flex;justify-content:space-between;font-size:13px;margin-top:4px;">
                    <span style="color:#868e96;">⏳ Hết hạn:</span>
                    <span id="displayExpiry">---</span>
                </div>
                <div style="display:flex;justify-content:space-between;font-size:13px;margin-top:4px;">
                    <span style="color:#868e96;">📱 Thiết bị:</span>
                    <span id="displayDevice">0 / 0</span>
                </div>
            </div>
            
            <!-- Chức năng -->
            <div style="font-size:13px;font-weight:500;color:#495057;margin:12px 0 4px;">📦 Chức năng</div>
            <div id="featureList"></div>
            
            <!-- Nhập UDID -->
            <div style="font-size:13px;font-weight:500;color:#495057;margin:16px 0 4px;">📱 Nhập UDID</div>
            <div class="form-group">
                <input type="text" id="udidInput" placeholder="VD: F2LQN1234567890ABCDEF" 
                       onkeydown="if(event.key==='Enter') generateConfig()">
            </div>
            
            <button class="btn" onclick="generateConfig()" id="btnDownload">⬇️ Tải cấu hình</button>
            
            <!-- Thông tin admin -->
            <div class="admin-contact">
                👨‍💻 Admin: <strong id="adminName">Đức Lâm X Quang Hào</strong> · 
                📱 Zalo: <a href="https://zalo.me/0879072010" target="_blank" id="adminZalo">0879072010</a>
            </div>
            
            <div style="margin-top:12px;text-align:center;">
                <a href="#" onclick="resetApp(); return false;" style="color:#adb5bd;font-size:12px;text-decoration:none;">← Nhập key khác</a>
            </div>
        </div>
        
        <div class="brand">DUCLAM.NET · Configuration Centre</div>
    </div>

    <script>
        let currentKey = '';
        let currentFeatures = {};
        let currentAdmin = {};
        
        function validateKey() {
            const key = document.getElementById('keyInput').value.trim();
            const msg = document.getElementById('msg');
            
            if (!key) {
                msg.className = 'msg error';
                msg.textContent = '⚠️ Vui lòng nhập key';
                return;
            }
            
            document.getElementById('btnCheck').textContent = 'Đang kiểm tra...';
            document.getElementById('btnCheck').disabled = true;
            
            fetch('validate_key.php?key=' + encodeURIComponent(key))
                .then(res => res.json())
                .then(data => {
                    document.getElementById('btnCheck').textContent = 'Kiểm tra key →';
                    document.getElementById('btnCheck').disabled = false;
                    
                    if (data.error) {
                        msg.className = 'msg error';
                        msg.textContent = data.error;
                        return;
                    }
                    
                    // Lưu dữ liệu
                    currentKey = key;
                    currentFeatures = data.features || {};
                    currentAdmin = data.admin_info || { name: 'Đức Lâm X Quang Hào', zalo: '0879072010' };
                    
                    // Chuyển sang step 2
                    document.getElementById('step-key').classList.add('hidden');
                    document.getElementById('step-udid').classList.remove('hidden');
                    
                    // Điền thông tin
                    document.getElementById('displayKey').textContent = key;
                    document.getElementById('displayExpiry').textContent = data.expires_at || 'Vĩnh viễn';
                    document.getElementById('displayDevice').textContent = (data.used_udid || 0) + ' / ' + (data.max_udid || 1);
                    document.getElementById('adminName').textContent = currentAdmin.name || 'Đức Lâm X Quang Hào';
                    document.getElementById('adminZalo').textContent = currentAdmin.zalo || '0879072010';
                    document.getElementById('adminZalo').href = 'https://zalo.me/' + (currentAdmin.zalo || '0879072010');
                    
                    // Hiển thị chức năng
                    const list = document.getElementById('featureList');
                    list.innerHTML = '';
                    const featureNames = {
                        'dns': '🌐 DNS tùy chỉnh',
                        'proxy': '🔗 Proxy',
                        'vpn': '🔒 VPN',
                        'certificate': '📜 Chứng chỉ bảo mật',
                        'ad_block': '🚫 Chặn quảng cáo',
                        'game_boost': '⚡ Tăng tốc game',
                        'wifi_optimize': '📶 Tối ưu WiFi'
                    };
                    
                    let hasFeature = false;
                    for (const [key, name] of Object.entries(featureNames)) {
                        if (currentFeatures[key]) {
                            hasFeature = true;
                            list.innerHTML += `<div class="feature-item">
                                <span class="icon">✅</span>
                                <span class="label">${name}</span>
                            </div>`;
                        }
                    }
                    if (!hasFeature) {
                        list.innerHTML = `<div class="feature-item" style="color:#868e96;">📭 Không có chức năng đặc biệt</div>`;
                    }
                })
                .catch(err => {
                    document.getElementById('btnCheck').textContent = 'Kiểm tra key →';
                    document.getElementById('btnCheck').disabled = false;
                    msg.className = 'msg error';
                    msg.textContent = '❌ Lỗi kết nối server';
                });
        }
        
        function generateConfig() {
            const udid = document.getElementById('udidInput').value.trim();
            
            if (!udid) {
                alert('⚠️ Vui lòng nhập UDID');
                return;
            }
            
            if (!/^[0-9A-Fa-f]{40}$/.test(udid)) {
                alert('⚠️ UDID không hợp lệ (phải 40 ký tự hex)');
                return;
            }
            
            document.getElementById('btnDownload').textContent = '⏳ Đang tạo...';
            document.getElementById('btnDownload').disabled = true;
            
            // Gửi request tạo file
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'generate.php';
            form.target = '_blank';
            
            const inputKey = document.createElement('input');
            inputKey.type = 'hidden';
            inputKey.name = 'key';
            inputKey.value = currentKey;
            form.appendChild(inputKey);
            
            const inputUdid = document.createElement('input');
            inputUdid.type = 'hidden';
            inputUdid.name = 'udid';
            inputUdid.value = udid;
            form.appendChild(inputUdid);
            
            document.body.appendChild(form);
            form.submit();
            document.body.removeChild(form);
            
            document.getElementById('btnDownload').textContent = '⬇️ Tải cấu hình';
            document.getElementById('btnDownload').disabled = false;
        }
        
        function resetApp() {
            document.getElementById('step-key').classList.remove('hidden');
            document.getElementById('step-udid').classList.add('hidden');
            document.getElementById('keyInput').value = '';
            document.getElementById('udidInput').value = '';
            document.getElementById('msg').className = 'msg';
            document.getElementById('msg').textContent = '';
            currentKey = '';
        }
    </script>
</body>
</html>