<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$key = $_GET['key'] ?? $_POST['key'] ?? '';
$ip = $_SERVER['REMOTE_ADDR'];

if (!$key) {
    die(json_encode(['error' => 'Vui lòng nhập key']));
}

// Load database
$data = json_decode(file_get_contents('config/database.json'), true);
$found_key = null;

foreach ($data['keys'] as $k) {
    if ($k['key_code'] === $key) {
        $found_key = $k;
        break;
    }
}

if (!$found_key) {
    die(json_encode(['error' => '❌ Key không tồn tại']));
}

// Kiểm tra hết hạn
if (strtotime($found_key['expires_at']) < time()) {
    die(json_encode(['error' => '❌ Key đã hết hạn']));
}

// Kiểm tra số lượng UDID
if ($found_key['used_udid'] >= $found_key['max_udid']) {
    die(json_encode(['error' => '❌ Key đã hết số lượng thiết bị cho phép']));
}

// Kiểm tra IP bị block
foreach ($data['blocked_ips'] ?? [] as $blocked_ip) {
    if ($blocked_ip === $ip) {
        die(json_encode(['error' => '❌ IP của bạn đã bị khóa']));
    }
}

// Trả về thông tin
echo json_encode([
    'valid' => true,
    'key' => $found_key['key_code'],
    'features' => $found_key['features'] ?? [],
    'admin_info' => $found_key['admin_info'] ?? [
        'name' => 'Đức Lâm X Quang Hào',
        'zalo' => '0879072010'
    ],
    'expires_at' => $found_key['expires_at'],
    'used_udid' => $found_key['used_udid'] ?? 0,
    'max_udid' => $found_key['max_udid'] ?? 1
]);