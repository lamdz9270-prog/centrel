<?php
session_start();
if ($_SESSION['role'] !== 'master') {
    die('🚫 Chỉ Master Admin mới có quyền!');
}

require_once '../config/db.php';
$data = loadDB();
$admins = $data['admins'];

// Xử lý cập nhật IP
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $username = $_POST['username'] ?? '';
    $new_ip = $_POST['new_ip'] ?? '';
    
    if ($_POST['action'] === 'update_ip') {
        foreach ($data['admins'] as &$admin) {
            if ($admin['username'] === $username) {
                $admin['registered_ip'] = $new_ip;
                saveDB($data);
                echo '<div class="msg success" style="display:block;">✅ Đã cập nhật IP cho ' . $username . '</div>';
                break;
            }
        }
    }
    
    if ($_POST['action'] === 'toggle_active') {
        foreach ($data['admins'] as &$admin) {
            if ($admin['username'] === $username) {
                $admin['is_active'] = !$admin['is_active'];
                saveDB($data);
                echo '<div class="msg success" style="display:block;">✅ Đã ' . ($admin['is_active'] ? 'mở khóa' : 'khóa') . ' tài khoản ' . $username . '</div>';
                break;
            }
        }
    }
    
    // Reload data
    $data = loadDB();
    $admins = $data['admins'];
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Admin</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <div class="container" style="max-width:720px;">
        <h1>👑 Quản lý Admin</h1>
        <p class="sub">Quản lý tài khoản admin con và IP đăng ký</p>
        
        <div style="margin:16px 0;">
            <a href="create_admin.php" class="btn btn-secondary btn-sm">+ Tạo admin mới</a>
            <a href="dashboard.php" class="btn btn-secondary btn-sm">← Về dashboard</a>
        </div>
        
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Tên hiển thị</th>
                        <th>IP đăng ký</th>
                        <th>Trạng thái</th>
                        <th>Key quota</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($admins as $admin): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($admin['username']) ?></strong></td>
                        <td><?= htmlspecialchars($admin['fullname']) ?></td>
                        <td style="font-size:12px;font-family:monospace;">
                            <?= $admin['registered_ip'] ?? '🔴 Chưa đăng nhập' ?>
                        </td>
                        <td>
                            <?= $admin['is_active'] ? '🟢 Hoạt động' : '🔴 Đã khóa' ?>
                        </td>
                        <td>
                            <?= ($admin['keys_used'] ?? 0) . '/' . ($admin['key_quota'] ?? 0) ?>
                        </td>
                        <td style="font-size:12px;">
                            <?php if ($admin['username'] !== 'master'): ?>
                                <!-- Form cập nhật IP -->
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="update_ip">
                                    <input type="hidden" name="username" value="<?= $admin['username'] ?>">
                                    <input type="text" name="new_ip" placeholder="IP mới" style="width:100px;padding:4px 8px;font-size:12px;border-radius:6px;">
                                    <button type="submit" class="btn btn-sm btn-secondary" style="padding:4px 10px;font-size:11px;">📡</button>
                                </form>
                                <!-- Toggle active -->
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="toggle_active">
                                    <input type="hidden" name="username" value="<?= $admin['username'] ?>">
                                    <button type="submit" class="btn btn-sm <?= $admin['is_active'] ? 'btn-danger' : 'btn-secondary' ?>" style="padding:4px 10px;font-size:11px;">
                                        <?= $admin['is_active'] ? '🔒' : '🔓' ?>
                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <div class="brand">DUCLAM.NET · Configuration Centre</div>
    </div>
</body>
</html>