<?php
// ========== ĐƯỜNG DẪN ==========
define('DB_PATH', __DIR__ . '/database.json');

// ========== ĐỌC DATABASE ==========
function loadDB() {
    if (!file_exists(DB_PATH)) {
        file_put_contents(DB_PATH, json_encode([
            'admins' => [],
            'login_attempts' => []
        ]));
    }
    return json_decode(file_get_contents(DB_PATH), true);
}

// ========== LƯU DATABASE ==========
function saveDB($data) {
    file_put_contents(DB_PATH, json_encode($data, JSON_PRETTY_PRINT));
}

// ========== TÌM ADMIN THEO USERNAME ==========
function findAdmin($username) {
    $data = loadDB();
    foreach ($data['admins'] as $admin) {
        if ($admin['username'] === $username) {
            return $admin;
        }
    }
    return null;
}

// ========== CẬP NHẬT IP CHO ADMIN ==========
function updateAdminIP($username, $new_ip) {
    $data = loadDB();
    foreach ($data['admins'] as &$admin) {
        if ($admin['username'] === $username) {
            // Lần đầu đăng nhập: set registered_ip
            if (empty($admin['registered_ip'])) {
                $admin['registered_ip'] = $new_ip;
            }
            $admin['current_ip'] = $new_ip;
            $admin['last_login'] = date('Y-m-d H:i:s');
            saveDB($data);
            return true;
        }
    }
    return false;
}

// ========== KIỂM TRA IP CÓ HỢP LỆ KHÔNG ==========
function isIPValid($username, $ip) {
    $admin = findAdmin($username);
    if (!$admin) return false;
    
    // Nếu chưa có IP đăng ký → cho phép (lần đầu)
    if (empty($admin['registered_ip'])) {
        return true;
    }
    
    // So sánh IP
    return $admin['registered_ip'] === $ip;
}

// ========== LOG ĐĂNG NHẬP ==========
function logLoginAttempt($username, $ip, $success, $reason = '') {
    $data = loadDB();
    $data['login_attempts'][] = [
        'username' => $username,
        'ip' => $ip,
        'attempted_at' => date('Y-m-d H:i:s'),
        'success' => $success,
        'reason' => $reason
    ];
    // Giữ log tối đa 1000 dòng
    if (count($data['login_attempts']) > 1000) {
        array_shift($data['login_attempts']);
    }
    saveDB($data);
}

// ========== TẠO ADMIN MỚI (CHỈ MASTER) ==========
function createAdmin($username, $password, $fullname, $role = 'admin', $key_quota = 10) {
    $data = loadDB();
    
    // Kiểm tra username đã tồn tại
    if (findAdmin($username)) {
        return ['error' => 'Username đã tồn tại'];
    }
    
    // Mã hóa password
    $hashed = password_hash($password, PASSWORD_DEFAULT);
    
    $new_admin = [
        'id' => 'A' . rand(1000, 9999),
        'username' => $username,
        'password' => $hashed,
        'fullname' => $fullname,
        'role' => $role,
        'created_at' => date('Y-m-d H:i:s'),
        'last_login' => null,
        'registered_ip' => null,
        'current_ip' => null,
        'is_active' => true,
        'key_quota' => $key_quota,
        'keys_used' => 0
    ];
    
    $data['admins'][] = $new_admin;
    saveDB($data);
    
    return ['success' => true, 'admin' => $new_admin];
}